// ── Роли ──────────────────────────────────────────────────────

export type UserRole = "owner" | "admin" | "manager";

// ── Пользователь из БД ─────────────────────────────────────────

export interface DbUser {
  id: string;
  created_at: string;
  email: string;
  password_hash: string;
  full_name: string | null;
  role: UserRole;
  is_active: boolean;
}

// ── Пользователь, доступный в приложении (без hash) ────────────
// Именно этот тип передаётся в layout, app-shell и т.д.

export interface CurrentUser {
  id: string;
  email: string;
  full_name: string | null;
  role: UserRole;
}
