import { NextResponse, type NextRequest } from "next/server";

const COOKIE_NAME = "session_token";

const PROTECTED_ROUTES = [
  "/dashboard",
  "/trips",
  "/orders",
  "/trucks",
  "/drivers",
  "/expenses",
  "/settings",
];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const hasSession = request.cookies.has(COOKIE_NAME);
  const isProtected = PROTECTED_ROUTES.some((r) => pathname.startsWith(r));

  // Гость → защищённый роут
  if (!hasSession && isProtected) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  // Залогиненный → /login
  if (hasSession && pathname === "/login") {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
