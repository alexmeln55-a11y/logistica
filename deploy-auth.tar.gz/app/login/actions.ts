"use server";

import { redirect } from "next/navigation";
import { pool } from "@/lib/db/postgres";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { createSession, deleteSession } from "@/lib/auth/session";
import type { DbUser } from "@/lib/auth/types";

export async function login(formData: FormData) {
  const email = (formData.get("email") as string).trim().toLowerCase();
  const password = formData.get("password") as string;

  const { rows } = await pool.query<DbUser>(
    `SELECT id, password_hash, is_active
     FROM   users
     WHERE  email = $1
     LIMIT  1`,
    [email]
  );

  const user = rows[0];
  const INVALID = "Неверный email или пароль";

  if (!user) return { error: INVALID };
  if (!user.is_active) return { error: "Учётная запись заблокирована" };

  const valid = await verifyPassword(password, user.password_hash);
  if (!valid) return { error: INVALID };

  await createSession(user.id);
  redirect("/dashboard");
}

export async function signUp(formData: FormData) {
  const email = (formData.get("email") as string).trim().toLowerCase();
  const password = formData.get("password") as string;
  const full_name = ((formData.get("full_name") as string) || "").trim() || null;

  if (!email || !password) {
    return { error: "Email и пароль обязательны" };
  }

  if (password.length < 8) {
    return { error: "Пароль должен быть не менее 8 символов" };
  }

  // Проверяем, занят ли email
  const { rows: existing } = await pool.query(
    `SELECT id FROM users WHERE email = $1 LIMIT 1`,
    [email]
  );
  if (existing.length > 0) {
    return { error: "Пользователь с таким email уже существует" };
  }

  // Первый пользователь получает роль owner, остальные — manager
  const { rows: countRows } = await pool.query<{ count: string }>(
    `SELECT count(*)::text FROM users`
  );
  const role = parseInt(countRows[0].count, 10) === 0 ? "owner" : "manager";

  const password_hash = await hashPassword(password);

  const { rows } = await pool.query<DbUser>(
    `INSERT INTO users (email, password_hash, full_name, role)
     VALUES ($1, $2, $3, $4)
     RETURNING id, is_active`,
    [email, password_hash, full_name, role]
  );

  const user = rows[0];
  if (!user) return { error: "Не удалось создать пользователя" };

  await createSession(user.id);
  redirect("/dashboard");
}

export async function logout() {
  await deleteSession();
  redirect("/login");
}
