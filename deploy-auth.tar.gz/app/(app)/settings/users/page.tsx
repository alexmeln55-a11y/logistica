import { requireAdminAccess } from "@/lib/auth/current-user";
import { EmptyState } from "@/components/empty-state";

export default async function UsersPage() {
  await requireAdminAccess();

  return (
    <EmptyState
      title="Пользователи"
      description="Управление доступами, ролями и приглашениями."
      actionLabel="Пригласить"
    />
  );
}
